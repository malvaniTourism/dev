import React from 'react';
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

import img1 from '../../assets/img/tour/1.png';
import img2 from '../../assets/img/tour/2.png';
import img3 from '../../assets/img/tour/3.png';
import img4 from '../../assets/img/tour/4.png';
import img5 from '../../assets/img/tour/5.png';
import img6 from '../../assets/img/tour/6.png';

const UpComming = () => {
    return (
        <div className="instagram-area pd-top-100">
            <div className="section-title text-center">
                <h2 className="title">Instagram Post</h2>
            </div>
            <div className="instagram-slider">
                <div className="instagram-slider-item">
                    <a href="#">
                        <img src={img1} alt="img" />
                    </a>
                </div>
                <div className="instagram-slider-item">
                    <a href="#">
                        <img src={img2} alt="img" />
                    </a>
                </div>
                <div className="instagram-slider-item">
                    <a href="#">
                        <img src={img3} alt="img" />
                    </a>
                </div>
                <div className="instagram-slider-item">
                    <a href="#">
                        <img src={img4} alt="img" />
                    </a>
                </div>
                <div className="instagram-slider-item">
                    <a href="#">
                        <img src={img5} alt="img" />
                    </a>
                </div>
                <div className="instagram-slider-item">
                    <a href="#">
                        <img src={img6} alt="img" />
                    </a>
                </div>
                <div className="instagram-slider-item">
                    <a href="#">
                        <img src={img1} alt="img" />
                    </a>
                </div>
            </div>
        </div>
    )
}

export default UpComming;