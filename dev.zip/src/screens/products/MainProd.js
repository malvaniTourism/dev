import React from "react";
import ProductHeader from "../../components/headers/ProductHeader";

const MainProd = () => {

    return (
        <div>
            <ProductHeader />
        </div>
    )
}

export default MainProd;