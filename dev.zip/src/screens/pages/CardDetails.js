import React from "react";

const CardDetails = () => {

    return (
        <div>
            Card Details
        </div>
    )
};

export default CardDetails;