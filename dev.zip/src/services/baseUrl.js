const Path = {
    API_PATH: 'https://tour.pranavkamble.in/api/',
}

export default Path;